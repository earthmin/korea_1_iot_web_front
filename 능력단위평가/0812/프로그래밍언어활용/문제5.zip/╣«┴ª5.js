//& 활용문제 5번 답안 js 
const button = document.getElementById('clickButton');
function clickButton() {
console.log("Button clicked!");
} 
button.addEventListener('click', clickButton); 

// >> 버튼 클릭시 개발자 도구에서 Button clicked! 출력 

//textContent
 
