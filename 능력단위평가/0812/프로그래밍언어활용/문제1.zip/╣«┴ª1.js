//& 활용 문제 1번 답안 
class User {
  // 생성자: 이름, 나이, 이메일을 받아 속성에 할당
constructor(name, age, email) {
    this.name = name;
    this.age = age;
    this.email = email;
}

printInfo() {
    console.log(`이름: ${this.name}`);
    console.log(`나이: ${this.age}`);
    console.log(`이메일: ${this.email}`);
}
}

const user1 = new User("마루", 4, "maru@naver.com");
user1.printInfo();


class Product {
    constructor(name, price) {
        this.name = name;
        this.price = price;
    }

    printProduct() {
        console.log(`상품명: ${this.name}`);
        console.log(`가격: ${this.price}원`);
    }
}

const product1= new Product("사료", 1500000);
product1.printProduct();

class Order {
  
constructor(user, product, quantity) {
    this.user = user;
    this.product = product;
    this.quantity = quantity;
}

  // 총 주문 금액을 계산하고 출력하는 메서드
printOrderSummary() {
      const totalAmount = this.product.price * this.quantity;
    console.log(`주문자: ${this.user.name}`);
    console.log(`상품명: ${this.product.name}`);
    console.log(`수량: ${this.quantity}`);
    console.log(`총 주문 금액: ${totalAmount}원`);
}
}

const order = new Order(user1, product1, 2);

// 주문 요약 출력
order.printOrderSummary();


